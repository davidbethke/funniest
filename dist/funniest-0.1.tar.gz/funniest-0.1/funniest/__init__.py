def joke():
    return ('something funny')
