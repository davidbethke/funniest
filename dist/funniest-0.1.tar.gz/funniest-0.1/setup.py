from setuptools import setup

setup(name='funniest', version='0.1', description='funny', url='http://github.com/davidbethke/funniest', author='jk', author_email='jk@gmail.com', license='MIT', packages=['funniest'], zip_safe=False)

